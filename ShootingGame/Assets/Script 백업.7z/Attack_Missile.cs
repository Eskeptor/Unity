﻿using UnityEngine;
using System.Collections;

public class Attack_Missile : MonoBehaviour {
    public float MissileSpeed = 20f;
    public bool check = false;

    //MemoryPool pool = new MemoryPool();
	
	// Update is called once per frame
	void Update () {
        this.transform.Translate(new Vector3(0, 0, 1) * MissileSpeed * Time.deltaTime);
        check = false;
	}
    void OnCollisionEnter(Collision col)
    {
        if (col.collider.tag == "Enemy")
        {
            col.collider.gameObject.SetActive(false);
            //col.collider.GetComponent<Collider>().enabled = false;
            //this.GetComponent<Collider>().enabled = false;
            //Destroy(col.collider.gameObject);
            //Destroy(this.gameObject);
            //pool.RemoveItem(col.collider.gameObject);
            //this.gameObject.SetActive(false);
            Debug.Log("적과 부딛힘");
            check = true;
            Debug.Log("AM : Check_Collision = " + check);
        }
        else
        {
            check = false;
        }
    }
    public bool Check_Collision()
    {
        return check;
    }
}
