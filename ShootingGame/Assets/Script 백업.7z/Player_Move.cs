﻿using UnityEngine;
using System.Collections;

public class Player_Move : MonoBehaviour {
    public float CharacterMoveSpeed = 3f;
    public float FireSpeed = 0.2f;
    public int MissilePoolCount = 20;
    public float DestroyMissileZpos = 20f;
    public GameObject MissileLeft;
    public GameObject MissileRIght;
    public GameObject Enemy;
    public Transform FireMissileRightLocation;
    public Transform FireMissileLeftLocation;
    public Transform EnemyLocation;
    public GameEvent_TargetDamage Target;
    public Attack_Missile am;

    MemoryPool pool = new MemoryPool();
    MemoryPool ene = new MemoryPool();
    GameObject[] missile_left;
    GameObject[] missile_right;
    GameObject enemy;

    bool check_collision;
    //RaycastHit hit;
    //int missile_cnt = 0;

    private bool Gun_Fire_State = true;

	// Use this for initialization
	void Start () {
        pool.Create(MissileLeft, MissilePoolCount);
        pool.Create(MissileRIght, MissilePoolCount);
        ene.Create(Enemy, 1);
        
        missile_left = new GameObject[MissilePoolCount];
        missile_right = new GameObject[MissilePoolCount];
        enemy = new GameObject();
        for(int i = 0; i < missile_left.Length; i++)
        {
            missile_left[i] = null;
            missile_right[i] = null;
        }
        enemy = ene.NewItem();
        enemy.transform.position = EnemyLocation.transform.position;
    }
    /*
    public IEnumerator MissileAttack()
    {
        Physics.Raycast(FireMissileLeftLocation.position, FireMissileLeftLocation.forward, out hit, 1);
        Physics.Raycast(FireMissileRightLocation.position, FireMissileRightLocation.forward, out hit, Mathf.Infinity);
        if (hit.collider)
        {
            if (hit.collider.tag == "Enemy")
            {
                ene.RemoveItem(hit.collider.gameObject);
                pool.RemoveItem(hit.collider.gameObject);
                Destroy(hit.collider.gameObject);
                Debug.Log("충돌");
            }
        }
        yield return null;
    }*/
    // Update is called once per frame
    void Update () {
        check_collision = am.Check_Collision();
        if (!MoveCharacter())
        {
            return;
        }
	}
    void OnApplicationQuit()
    {
        pool.Dispose();
    }
    private void FireSpeedControl()
    {
        Gun_Fire_State = true;
    }
    bool MoveCharacter()
    {
        
        if (Input.GetKey(KeyCode.UpArrow))
        {
            this.transform.Translate(new Vector3(0, 0, 1) * CharacterMoveSpeed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.DownArrow))
        {
            this.transform.Translate(new Vector3(0, 0, 1) * -1*  CharacterMoveSpeed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            this.transform.Translate(new Vector3(1, 0, 0) * -1 * CharacterMoveSpeed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
            this.transform.Translate(new Vector3(1, 0, 0) * CharacterMoveSpeed * Time.deltaTime);
        }
        if (Input.GetKey(KeyCode.P))
        {
            Debug.Log("PM : Check_Collision = " + check_collision);
        }
        if (Input.GetKey(KeyCode.O))
        {
            check_collision = true;
            Debug.Log("PM : Check_Collision = " + check_collision);
        }
        if (Gun_Fire_State)
        {
            if (Input.GetKey(KeyCode.A))
            {
                Invoke("FireSpeedControl", FireSpeed);
                for(int i = 0; i < missile_left.Length; i++)
                {
                    if (missile_left[i] == null && missile_right[i] == null)
                    {
                        missile_right[i] = pool.NewItem();
                        missile_left[i] = pool.NewItem();
                        missile_right[i].transform.position = FireMissileRightLocation.transform.position;
                        missile_left[i].transform.position = FireMissileLeftLocation.transform.position;
                        break;
                    }
                }     
                Debug.Log("총 발사됨");
                Gun_Fire_State = false;
                StartCoroutine(Target.MissileAttack());
            }
        }
        
        for(int i = 0; i < missile_left.Length; i++)
        {
            
            // 간혹 미사일이 안사라지는 버그때문에 두 if문을 안합침( && 를 쓰면 간혹 씹혀버림)
            if (missile_left[i] || missile_right[i])
            {
                 if(missile_left[i].transform.position.z > DestroyMissileZpos || missile_right[i].transform.position.z > DestroyMissileZpos)
                 {
                    pool.RemoveItem(missile_left[i]);
                    missile_left[i] = null;
                    pool.RemoveItem(missile_right[i]);
                    missile_right[i] = null;
                    Debug.Log("PM : Check_Collision = " + check_collision);
                }
                if (check_collision)
                {
                    Debug.Log("PM : Check_Collision = " + check_collision);
                    pool.RemoveItem(missile_left[i]);
                    missile_left[i] = null;
                    pool.RemoveItem(missile_right[i]);
                    missile_right[i] = null;
                }
            }
            /*
            if (missile_right[i])
            {
                if(missile_right[i].transform.position.z > DestroyMissileZpos)
                {
                    pool.RemoveItem(missile_right[i]);
                    missile_right[i] = null;
                }
            }*/
        }
        return true;
    }
    
}
