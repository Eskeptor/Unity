﻿public class Enemy_Data {
    private int hp; // 적 기체의 체력
    
    public Enemy_Data(int _hp)  // 생성자
    {
        hp = _hp;
    }
    // Enemy_Data enemy = new Enemy_Data(50); -> 체력이 50인 적의 데이터

    public int HP
    {
        get
        {
            // enemy.HP; 현재 hp를 반환
            return hp;
        }
        set
        {
            // emeny.HP = 30; 현재 hp를 30으로 변경
            hp = value;
        }
    }
}
