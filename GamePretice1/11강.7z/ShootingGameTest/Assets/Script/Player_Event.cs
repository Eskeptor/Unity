﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Player_Event : MonoBehaviour {
    public GameObject Player;           // 플레이어를 저장할 게임오브젝트
    public int PlayerHP;                // 플레이어의 체력을 에디터에서 설정할 수 있도록 하는 변수
    public Slider HPBar;
    private Player_Data playerData;     // 실질적인 플레이어의 체력을 저장하는 곳

	// Use this for initialization
	void Start () {
        playerData = new Player_Data(PlayerHP); // 체력을 설정
        HPBar.maxValue = PlayerHP;
        HPBar.value = PlayerHP;
    }
	
	// Update is called once per frame
	void Update () {
        HPCheck();                              // 매 프레임마다 HPCheck 메소드 실행
	}

    // 에너지를 감소시키는 메소드
    public void UnderAttack(int _damage)
    {
        playerData.HP -= _damage;
    }

    void HPCheck()
    {
        // 체력 동기화
        PlayerHP = playerData.HP;
        if (PlayerHP <= 0)       // 체력이 0보다 적거나 같으면
        {
            PlayerHP = 0;
            Destroy(Player);    // 플레이어 소멸
        }
        HPBar.value = PlayerHP;
    }
}
