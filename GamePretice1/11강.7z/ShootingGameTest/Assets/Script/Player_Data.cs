﻿public class Player_Data {
    private int hp;

    public Player_Data(int _hp)
    {
        hp = _hp;
    }

	public int HP   // get set 방식의 HP
    {
        get
        {
            return hp;
        }
        set
        {
            hp = value;
        }
    }
}
